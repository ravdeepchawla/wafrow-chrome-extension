chrome.devtools.panels.elements.createSidebarPane(
    "Wafrow", function(sidebar) {
      sidebar.setPage("panel.html");
  }
);
